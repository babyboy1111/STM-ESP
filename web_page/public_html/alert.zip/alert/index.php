<!DOCTYPE html>
<html>
    <title></title>
    <header>
        <link rel="stylesheet" href="https://dnmtechs.com/project/checkip/css/bootstrap.min.css">
        <link rel="stylesheet" href="./assets/css/grid.css">
        <link rel="stylesheet" href="./assets/css/style.css">
    </header>

    <body>
      <div class="slider">
        <div class="contain">
            <h2  style="color:#fff">Hẹn giờ tưới cây</h2>
            <form method="post" action="index.php" class="form">

            Giờ: <input class="input" type="time" name="time" value="" required step="1">

            Thời gian: <input class="input" type="time" name="timeBom" value="" step="1" required >

            Máy bơm: <input class="input" type="number" name="bom" value="" required/>

            <input class="button" type="submit" name="OK" value="Đặt"/>
            <?php require 'xuly.php';?>
            </form>
            <table class="table1" >
            <tr>
            <td>Thời gian</td>
            <td>Thời gian bơm</td>
            <td>Bơm</td>
            <td></td>
            <td></td>
            </tr>
            <?php
            require 'connect.php';
            $query=mysqli_query($conn,"select * from `set_time`");
            while($row=mysqli_fetch_array($query)){
            ?>
            <tr>
            <td><?php echo $row['time']; ?></td>
            <td><?php echo $row['timeBom']; ?></td>
            <td><?php echo $row['bom']; ?></td>
            <td><a href="edit_time.php?id=<?php echo $row['id']; ?>">Edit</a></td>
            <td><a href="delete_time.php?id=<?php echo $row['id']; ?>">Delete</a></td>
            </tr>
            <?php
            }
            ?>
            </table>
            <form action="" method="post">
                <button class="button" name="RESET" value="RESET">RESET</button>
            </form>
                <?php require 'reset.php';?>
            <form action="" method="post">
             <input class="input" type="text" name="search"></input>
                <input class="button" type="submit" name="submit" value="Tìm Kiếm"></input>
            </form>
            <?php
            include 'connect.php';
            if(ISSET($_POST['submit'])){
                 $keyword=$_POST['search'];
                 echo $keyword;
                    $query=msqli_query($conn,"SELECT * FROM tree WHERE plant LIKE '%$keyword%' ORDER BY id") or die(mysqli_error());
                    $fetch = mysqli_fetch_array($query);
                    echo $fetch['temp'];
            
             ?>   
                <p>Nhiệt độ khuyến cáo <?php echo $fetch['temp']?></p>
            <?php
        
               }
            
            ?>
            
        </div>
        <div class="container">
            <?php
                require_once("get_data.php");
                $access_key = "&appid=f3cc6ba52ca8ca7b5b8af972c88fb5e2";
                $ip_obj = sendJsontoServer();
                $country = $ip_obj->country_name;
                $region = $ip_obj->region_name;
                if(!$region){
                    $region = $ip_obj->location->capital;
                }
                $current_obj = getCurrentData($region, $country, $access_key);
                $city_id = $current_obj->id;
                $forcast_obj = getForcast($city_id, $access_key);
            ?>
            <?php $forcast_list = $forcast_obj->list;
                        $total=10000;
                        $nhiet=0;
                        $doam=0;
                        foreach($forcast_list as $temp){ 
                           $total+= $temp->pop;
                           $doam+=$temp->main->humidity;
                           $nhiet+=$temp->main->temp;
                          }
                        $message="";
                        $total=$total/40;
                        $doam=$doam/40;
                        $nhiet=$nhiet/40;
                        if ($total<20 && $doam<70){
                            $message="<h2>Khả năng mưa những ngày sắp tới là '$total' %, trời hanh khô cây của bạn sẽ cần nhiều nước đấy</h2>";
                        } else if(20<$total && 70<$doam){
                            $message="<h2>Khả năng mưa những ngày sắp tới là '$total' %, trời sẽ có mưa nhưng rải rác, cây của bạn cần một lượng nước vừa đủ</h2>";
                        } else if($total>50 && $doam>80){
                            $message="<h2>Khả năng mưa những ngày sắp tới là '$total' %, trời mưa nhiều, bạn có thể tắt máy bơm của mình đi một vài ngày</h2>";
                        }
                        echo $message;
                        if($nhiet>35){
                            include 'connect.php';
                            $sql        =   "SELECT timeBom FROM set_time WHERE bom='1' LIMIT 1";
                            $result     =   $conn->query($sql);

                            $row = $result->fetch_assoc();

                            $total= $row['timeBom'][7]+$row['timeBom'][6]*10+$row['timeBom'][4]*60+$row['timeBom'][3]*600;
                            $total=$total*1.25;
                            $row['timeBom'][7]=$total%10;
                            $row['timeBom'][6]=floor(($total%60)/10);
                            $row['timeBom'][4]=floor($total/60)%10;
                            $row['timeBom'][3]=floor($total/600);
                            $bien=$row['timeBom'];
                            $sql = "UPDATE set_time SET timeBom='$bien' WHERE bom='1'";
        
                                 if ($conn->query($sql) === TRUE) {
                                    echo "New record created successfully";
                                    } 
                                    else {
                                     echo "Error: " . $sql . "<br>" . $conn->error;
                                    }
                            
    
                            $conn->close();
                        }else if($total>30){
                            include 'connect.php';
                            $sql        =   "SELECT timeBom FROM set_time WHERE bom='1' LIMIT 1";
                            $result     =   $conn->query($sql);

                            $row = $result->fetch_assoc();

                            $total= $row['timeBom'][7]+$row['timeBom'][6]*10+$row['timeBom'][4]*60+$row['timeBom'][3]*600;
                            $total=$total*0.70;
                            $row['timeBom'][7]=$total%10;
                            $row['timeBom'][6]=floor(($total%60)/10);
                            $row['timeBom'][4]=floor($total/60)%10;
                            $row['timeBom'][3]=floor($total/600);
                            $bien=$row['timeBom'];
                            $sql = "UPDATE set_time SET timeBom='$bien' WHERE bom='1'";
        
                                 if ($conn->query($sql) === TRUE) {
                                    echo "New record created successfully";
                                    } 
                                    else {
                                     echo "Error: " . $sql . "<br>" . $conn->error;
                                    }
                            
    
                            $conn->close();
                        }
             ?>
            <div class="col-md-10 col-md-10 col-md-12 col-md-12">
                <div class="row">
                    <div class="col-md-5">Location: <?php echo $region.", ".$country ?></div>
                    <div class="col-md-5">Update Time: <?php echo date("d/m/Y H:i:s",$current_obj->dt); ?></div>
                </div>
                <div class="row">
                    <div class="col-md-5 text-center">
                        <div style="height:50px; width:50px; margin-left:auto;margin-right:auto;
                             background: url('http://openweathermap.org/img/w/<?php echo $current_obj->weather[0]->icon ?>.png');background-size: cover;"></div>
                        <div><?php echo $current_obj->main->temp." &#8451;" ?> - <?php echo  $current_obj->weather[0]->main ?></div>
                        <div>Cloudiness: <?php echo $current_obj->clouds->all."%" ?></div>
                    </div>
                    <div class="col-md-5">
                        <div>Pressure: <?php echo $current_obj->main->pressure."hPa" ?></div>
                        <div>Humidity: <?php echo $current_obj->main->humidity."%" ?></div>
                        <div>Min Temp: <?php echo $current_obj->main->temp_min." &#8451;" ?></div>
                        <div>Max Temp: <?php echo $current_obj->main->temp_max." &#8451;" ?></div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-5">Wind Speed: <?php echo $current_obj->wind->speed." meter/sec" ?></div>
                    <div class="col-md-5">Wind Direction: <?php echo $current_obj->wind->deg."&deg;" ?></div>
                </div>
                <div class="row">
                    <div class="col-md-5">Sunrise: <?php echo date("H:i:s",$current_obj->sys->sunrise); ?></div>
                    <div class="col-md-5">Sunset: <?php echo date("H:i:s",$current_obj->sys->sunset); ?></div>
                </div>
            </div>
            <div class="row">
                    <?php 
                        $forcast_list = $forcast_obj->list;
                        foreach($forcast_list as $temp){ 
                            ?>
                <div class="col-md-2 text-center" style="border: 1px solid;">
                    <div class="col-md-12"><b><?php echo date("d/m H:i",$temp->dt) ?></b></div>
                             <div class="col-md-12" style="height:50px; width:50px; margin-left:auto;margin-right:auto;
                             background: url('http://openweathermap.org/img/w/<?php echo $temp->weather[0]->icon ?>.png') no-repeat;"></div>
                             <div class="col-md-12"><?php echo $temp->main->temp." &#8451;" ?></div>
                             <div class="col-md-12"><?php echo $temp->main->humidity."%" ?></div>
                             <div class="col-md-12"><?php echo $temp->weather[0]->main ?></div>
                        </div>
                            <?php }
                    ?>
                </div>
        </div>
       </div>
       <!-- kết thúc slider -->
    </body>
</html>