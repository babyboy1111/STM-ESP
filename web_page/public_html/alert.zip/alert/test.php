<?php $forcast_list = $forcast_obj->list;
                        $total=10000;
                        $nhiet=0;
                        $doam=0;
                        foreach($forcast_list as $temp){ 
                           $total+= $temp->pop;
                           $doam+=$temp->main->humidity;
                           $nhiet+=$temp->main->temp;
                          }
                        $message="";
                        $total=$total/40;
                        $doam=$doam/40;
                        $nhiet=$nhiet/40;
                        if ($total<20 && $doam<70){
                            $message="<h2>Khả năng mưa những ngày sắp tới là '$total' %, trời hanh khô cây của bạn sẽ cần nhiều nước đấy</h2>";
                        } else if(20<$total && 70<$doam){
                            $message="<h2>Khả năng mưa những ngày sắp tới là '$total' %, trời sẽ có mưa nhưng rải rác, cây của bạn cần một lượng nước vừa đủ</h2>";
                        } else if($total>50 && $doam>80){
                            $message="<h2>Khả năng mưa những ngày sắp tới là '$total' %, trời mưa nhiều, bạn có thể tắt máy bơm của mình đi một vài ngày</h2>";
                        }
                        echo $message;
                        if($nhiet>35){
                            $servername = "localhost";

                            // REPLACE with your Database name
                            $dbname = "demo2";
                           // REPLACE with Database user
                            $username = "root";
                           // REPLACE with Database user password
                            $password = "";
                            $conn= new mysqli($servername,$username,$password,$dbname);
                            if($conn->connect_error){
                                die("connection failed :".$connect_error);
                            }
                            $sql        =   "SELECT timeBom FROM set_time WHERE bom='1' LIMIT 1";
                            $result     =   $conn->query($sql);

                            $row = $result->fetch_assoc();

                            $total= $row['timeBom'][7]+$row['timeBom'][6]*10+$row['timeBom'][4]*60+$row['timeBom'][3]*600;
                            $total=$total*1.25;
                            $row['timeBom'][7]=$total%10;
                            $row['timeBom'][6]=floor(($total%60)/10);
                            $row['timeBom'][4]=floor($total/60)%10;
                            $row['timeBom'][3]=floor($total/600);
                            $bien=$row['timeBom'];
                            $sql = "UPDATE set_time SET timeBom='$bien' WHERE bom='1'";
        
                                 if ($conn->query($sql) === TRUE) {
                                    echo "New record created successfully";
                                    } 
                                    else {
                                     echo "Error: " . $sql . "<br>" . $conn->error;
                                    }
                            
    
                            $conn->close();
                        }else if($total>30){
                            $servername = "localhost";

                            // REPLACE with your Database name
                            $dbname = "demo2";
                           // REPLACE with Database user
                            $username = "root";
                           // REPLACE with Database user password
                            $password = "";
                            $conn= new mysqli($servername,$username,$password,$dbname);
                            if($conn->connect_error){
                                die("connection failed :".$connect_error);
                            }
                            $sql        =   "SELECT timeBom FROM set_time WHERE bom='1' LIMIT 1";
                            $result     =   $conn->query($sql);

                            $row = $result->fetch_assoc();

                            $total= $row['timeBom'][7]+$row['timeBom'][6]*10+$row['timeBom'][4]*60+$row['timeBom'][3]*600;
                            $total=$total*0.70;
                            $row['timeBom'][7]=$total%10;
                            $row['timeBom'][6]=floor(($total%60)/10);
                            $row['timeBom'][4]=floor($total/60)%10;
                            $row['timeBom'][3]=floor($total/600);
                            $bien=$row['timeBom'];
                            $sql = "UPDATE set_time SET timeBom='$bien' WHERE bom='1'";
        
                                 if ($conn->query($sql) === TRUE) {
                                    echo "New record created successfully";
                                    } 
                                    else {
                                     echo "Error: " . $sql . "<br>" . $conn->error;
                                    }
                            
    
                            $conn->close();
                        }
             ?>