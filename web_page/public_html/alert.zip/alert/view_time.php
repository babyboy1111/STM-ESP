<table border="1">
<tr>
<td>ID</td>
<td>Username</td>
<td>Email</td>
<td>Phone</td>
</tr>
<?php
require 'connect.php';
$query=mysqli_query($conn,"select * from `set_time`");
while($row=mysqli_fetch_array($query)){
?>
<tr>
<td><?php echo $row['id']; ?></td>
<td><?php echo $row['time']; ?></td>
<td><?php echo $row['temp']; ?></td>
<td><?php echo $row['humid']; ?></td>
<td><a href="edit_time.php?id=<?php echo $row['id']; ?>">Edit</a></td>
<td><a href="delete_time.php?id=<?php echo $row['id']; ?>">Delete</a></td>
</tr>
<?php
}
?>
</table>